﻿# [Your Service Name] Windows Service

A .NET Core Windows Service that [briefly describe what your service does].

## 📋 Features
- Feature 1
- Feature 2
- Feature 3

## ⚙️ Prerequisites
- [.NET Core 6.0/7.0/8.0 SDK](https://dotnet.microsoft.com/download)
- Windows Server/Windows 10/11
- PowerShell 5.1+
- Administrator privileges (for service installation)

## 🚀 Installation

Install service

New-Service -Name "BixanaCloudSync"  -BinaryPathName "D:\Projects\Medical\Brookhollow\windows\SyncDataService\SyncDataService\bin\Debug\netcoreapp3.1\publish\SyncDataService.exe" -Description "Process Service" -DisplayName "Sync data process" -StartupType Automatic
New-Service -Name "BixanaCloudSync"  -BinaryPathName "C:\SyncOpendentalData\SyncDataService\SyncDataService.exe" -Description "Process Service" -DisplayName "Sync data process" -StartupType Automatic

New-Service -Name "BixanaCloudSync"  -BinaryPathName "D:\Projects\Medical\Brookhollow\windows\SyncDataService\SyncDataService\bin\Debug\netcoreapp3.1\publish\BixanaDataSyncer.exe" -Description "Process Service" -DisplayName "Sync data process" -StartupType Automatic
New-Service -Name "BixanaCloudSync"  -BinaryPathName "C:\SyncOpendentalData\SyncDataService\BixanaDataSyncer.exe" -Description "Process Service" -DisplayName "Sync data process" -StartupType Automatic


Delete
sc.exe delete SyncDataService

Core 3.1.2
https://download.visualstudio.microsoft.com/download/pr/326b33d1-6bbd-4149-ba35-c94784700674/c06386c2b09401fa94f9595617899d5d/aspnetcore-runtime-3.1.2-win-x64.exe


    # Create the Windows Service
    $serviceName = "YourServiceName"
    $exePath = "C:\full\path\to\publish\YourService.exe"
    $displayName = "Your Service Display Name"

    New-Service -Name $serviceName `
                -BinaryPathName $exePath `
                -DisplayName $displayName `
                -Description "Description of your service" `
                -StartupType Automatic

    # Start the service
    Start-Service -Name $serviceName

    # Verify service status
    Get-Service -Name $serviceName

    #Using SC.EXE
    sc.exe create $serviceName binPath= $exePath start= auto DisplayName= $displayName
    sc.exe description $serviceName "Your service description"
    sc.exe start $serviceName

    #Start/Stop/Restart Service
    # Start
    Start-Service -Name "YourServiceName"

    # Stop
    Stop-Service -Name "YourServiceName" -Force

    # Restart
    Restart-Service -Name "YourServiceName" -Force

    # Check status
    Get-Service -Name "YourServiceName"


    # Stop first
    Stop-Service -Name "YourServiceName" -Force

    # Uninstall
    Remove-Service -Name "YourServiceName"

    # Alternative using SC
    sc.exe delete "YourServiceName"



### 1. Build the Service
```powershell
# Clone the repository
git clone https://github.com/your-repo/your-service.git
cd your-service

# Restore dependencies and build
dotnet restore
dotnet publish -c Release -o ./publish

