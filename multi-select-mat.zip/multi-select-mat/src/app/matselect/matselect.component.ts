import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { SelectAutocompleteComponent } from 'mat-select-autocomplete';

@Component({
  selector: 'app-matselect',
  templateUrl: './matselect.component.html',
  styleUrls: ['./matselect.component.css']
})
export class MatselectComponent implements OnInit {

  @ViewChild(SelectAutocompleteComponent) multiSelect: SelectAutocompleteComponent;

  ngOnInit(){}
  districtOptions = [
    {
      display: 'District 1',
      value: 'District 1'
    }, {
      display: 'District 2',
      value: 'District 2'
    }, {
      display: 'District 3',
      value: 'District 3'
    }, {
      display: 'District 4',
      value: 'District 4'
    }, {
      display: 'District 5',
      value: 'District 5'
    }, {
      display: 'District 6',
      value: 'District 6'
    }
  ];

  chcOptions = [
    {
      display: 'CHC 1',
      value: 'CHC 1'
    },
    {
      display: 'CHC 2',
      value: 'CHC 2'
    },
    {
      display: 'CHC 3',
      value: 'CHC 3'
    }

  ];

  selectedDistrictOptions = ['District 2','District 3'];
  selectedChcOptions = ['CHC 1', 'CHC 3'];
  selected_district = this.selectedDistrictOptions;
  selected_chc = this.selectedChcOptions;

  profileForm = new FormGroup({
    selected_district: new FormControl([]),
    selected_chc: new FormControl([])
  });

  constructor() { }

  onToggleDropdown() {
    this.multiSelect.toggleDropdown();
  }

  getSelectedDistrictsOptions(selected) {
    this.selected_district = selected;
    console.log(this.selected_district);
  }

  getSelectedChcOptions(selected){
    this.selected_chc = selected
    console.log(this.selected_chc);
  }

  onSubmit() {
    console.log(this.profileForm.value.selected);
  }

}
